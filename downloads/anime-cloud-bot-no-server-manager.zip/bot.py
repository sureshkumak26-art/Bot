import os,io,json,secrets
from datetime import datetime
import discord
from discord.ext import commands
from dotenv import load_dotenv
import qrcode

load_dotenv()
TOKEN=os.getenv("DISCORD_TOKEN",""); OWNER_ID=int(os.getenv("OWNER_ID","0") or 0)
with open("config.json",encoding="utf-8") as f: cfg=json.load(f)

def save():
    with open("config.json","w",encoding="utf-8") as f: json.dump(cfg,f,indent=2)

def staff(m):
    return m.id==OWNER_ID or m.id in cfg.get("admins",[]) or (
        cfg.get("roles",{}).get("support",0) and any(r.id==cfg["roles"]["support"] for r in getattr(m,"roles",[])))

def E(title,desc="",color=0x8B5CF6):
    e=discord.Embed(title=title,description=desc,color=color,timestamp=datetime.utcnow())
    e.set_footer(text="☁️ Anime Cloud"); return e

class TicketPanel(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)
    @discord.ui.select(custom_id="anime_ticket_type",placeholder="🎫 Choose support category",options=[
        discord.SelectOption(label="General Support",value="general",emoji="🎫"),
        discord.SelectOption(label="Billing / Payment",value="billing",emoji="💳"),
        discord.SelectOption(label="VPS / Hosting",value="hosting",emoji="☁️"),
        discord.SelectOption(label="Domain",value="domain",emoji="🌐"),
        discord.SelectOption(label="Technical Support",value="technical",emoji="🛠️")])
    async def choose(self,i,s):
        typ=s.values[0]; g=i.guild
        cat=discord.utils.get(g.categories,name=f"Anime Cloud • {typ.title()}")
        if not cat: cat=await g.create_category(f"Anime Cloud • {typ.title()}")
        overwrites={g.default_role:discord.PermissionOverwrite(view_channel=False),
                    i.user:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)}
        role=g.get_role(cfg.get("roles",{}).get("support",0))
        if role: overwrites[role]=discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)
        ch=await g.create_text_channel(f"ticket-{i.user.name}-{secrets.token_hex(2)}"[:95],category=cat,overwrites=overwrites)
        await ch.send(embed=E(f"🎫 {typ.title()} Ticket",f"{i.user.mention}, welcome to **Anime Cloud Support**."),view=TicketControls())
        await i.response.send_message(f"✅ Ticket created: {ch.mention}",ephemeral=True)

class TicketControls(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)
    @discord.ui.button(label="Claim",style=discord.ButtonStyle.primary,emoji="👤",custom_id="ac_claim")
    async def claim(self,i,b):
        if not staff(i.user): return await i.response.send_message("⛔ Staff only.",ephemeral=True)
        await i.response.send_message(embed=E("👤 Ticket Claimed",f"Claimed by {i.user.mention}."))
    @discord.ui.button(label="Close",style=discord.ButtonStyle.danger,emoji="🔒",custom_id="ac_close")
    async def close(self,i,b):
        if not staff(i.user): return await i.response.send_message("⛔ Staff only.",ephemeral=True)
        await i.channel.edit(name=f"closed-{i.channel.name}"[:95])
        await i.response.send_message("🔒 Ticket closed.")
    @discord.ui.button(label="Reopen",style=discord.ButtonStyle.success,emoji="🔓",custom_id="ac_reopen")
    async def reopen(self,i,b):
        if not staff(i.user): return await i.response.send_message("⛔ Staff only.",ephemeral=True)
        await i.channel.edit(name=i.channel.name.replace("closed-","",1))
        await i.response.send_message("🔓 Ticket reopened.")
    @discord.ui.button(label="Transcript",style=discord.ButtonStyle.secondary,emoji="📄",custom_id="ac_transcript")
    async def transcript(self,i,b):
        if not staff(i.user): return await i.response.send_message("⛔ Staff only.",ephemeral=True)
        lines=[]
        async for m in i.channel.history(limit=None,oldest_first=True): lines.append(f"[{m.created_at:%Y-%m-%d %H:%M}] {m.author}: {m.content}")
        await i.response.send_message(file=discord.File(io.BytesIO("\n".join(lines).encode()),filename=f"{i.channel.name}.txt"),ephemeral=True)

class Bot(commands.Bot):
    async def setup_hook(self):
        self.add_view(TicketPanel()); self.add_view(TicketControls())
bot=Bot(command_prefix="-",intents=discord.Intents.all())

@bot.event
async def on_ready():
    print(f"☁️ Anime Cloud online as {bot.user}")
    await bot.change_presence(activity=discord.Game(name=cfg.get("bot_status","Support & Payments")))

@bot.command()
async def help(ctx):
    await ctx.send(embed=E("☁️ Anime Cloud","`-ticketpanel` • tickets\n`-plans` • plans\n`-plan <name>` • plan details\n`-qrcode <amount>` • UPI QR\n`-announce <message>` • announcement"))

@bot.command()
async def ticketpanel(ctx):
    if staff(ctx.author): await ctx.send(embed=E("🎫 Anime Cloud Support","Select a category to create a private ticket."),view=TicketPanel())

@bot.command()
async def plans(ctx):
    d="\n".join(f"**{n}** — ₹{p['price']}/month • {p['ram']} RAM • {p['disk']} • {p['cpu']}" for n,p in cfg["plans"].items())
    await ctx.send(embed=E("☁️ Anime Cloud Plans",d,0x10B981))

@bot.command()
async def plan(ctx,name:str):
    p=cfg["plans"].get(name)
    if not p: return await ctx.send("❌ Plan not found.")
    await ctx.send(embed=E(f"☁️ {name}",f"**₹{p['price']}/month**\nRAM: {p['ram']}\nStorage: {p['disk']}\nCPU: {p['cpu']}"))

@bot.command()
async def qrcode(ctx,amount:float):
    if amount<=0: return await ctx.send("❌ Invalid amount.")
    upi=os.getenv("UPI_ID") or cfg["payment"]["upi_id"]; name=os.getenv("PAYMENT_NAME") or cfg["payment"]["name"]
    payload=f"upi://pay?pa={upi}&pn={name.replace(' ','%20')}&am={amount:.2f}&cu=INR"
    img=qrcode.make(payload); buf=io.BytesIO(); img.save(buf,"PNG"); buf.seek(0)
    await ctx.send(embed=E("💳 Anime Cloud Payment QR",f"**Amount:** ₹{amount:.2f}\n**UPI:** `{upi}`"),file=discord.File(buf,"anime-cloud-payment.png"))

@bot.command()
async def announce(ctx,*,message):
    if staff(ctx.author): await ctx.send(embed=E("📢 Anime Cloud Announcement",message,0x3B82F6))

@bot.command()
async def addadmin(ctx,member:discord.Member):
    if ctx.author.id!=OWNER_ID: return
    if member.id not in cfg["admins"]: cfg["admins"].append(member.id); save()
    await ctx.send(f"✅ {member.mention} added as Anime Cloud admin.")

bot.run(TOKEN)
