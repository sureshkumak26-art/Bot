# Anime Cloud Bot

Pterodactyl/server-manager functionality removed.

Features: tickets, multiple tickets per user, claim, close/reopen, transcripts, UPI QR, plans, announcements and admin controls.

Install: `python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt && cp .env.example .env && nano .env && python bot.py`
